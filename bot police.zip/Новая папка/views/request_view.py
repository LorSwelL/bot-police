import discord
from discord.ui import View, Button
import logging
import asyncio

from config import Config
from enums import RequestType
import state
from utils.rate_limiter import apply_role_changes, safe_discord_call
from utils.embed_utils import update_embed_status, add_officer_field, copy_embed
from services.audit import send_to_audit
from services.action_locks import action_lock
from database import delete_request
from modals.reject_reason import RejectReasonModal
from modals.edit_request import EditRequestModal
from constants import StatusValues, FieldNames
from views.theme import GREEN
from views.message_texts import AcceptMessages, ErrorMessages, SuccessMessages
from utils.interaction_helpers import safe_followup_or_response

logger = logging.getLogger(__name__)


class RequestView(View):
    def __init__(self, user_id: int, validated_data: dict, request_type: RequestType, **kwargs):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.validated_data = validated_data
        self.request_type = request_type
        self.additional_data = kwargs

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not interaction.guild:
            await interaction.response.send_message("❌ Команда доступна только на сервере.", ephemeral=True)
            return False

        custom_id = (interaction.data or {}).get("custom_id")
        if custom_id in ["accept", "reject"]:
            staff_role_id = self.request_type.get_staff_role_id()
            if not staff_role_id:
                await interaction.response.send_message(ErrorMessages.NO_PERMISSION, ephemeral=True)
                return False
            staff_role = interaction.guild.get_role(staff_role_id)
            if not staff_role or staff_role not in interaction.user.roles:
                await interaction.response.send_message(ErrorMessages.NO_PERMISSION, ephemeral=True)
                return False
        elif custom_id == "edit":
            if interaction.user.id != self.user_id:
                await interaction.response.send_message("❌ это не ваша заявка!", ephemeral=True)
                return False
        return True

    @discord.ui.button(label="✅ Принять", style=discord.ButtonStyle.success, custom_id="accept")
    async def accept_button(self, interaction: discord.Interaction, button: Button):
        await self.handle_accept(interaction)

    @discord.ui.button(label="❌ Отклонить", style=discord.ButtonStyle.danger, custom_id="reject")
    async def reject_button(self, interaction: discord.Interaction, button: Button):
        modal = RejectReasonModal(user_id=self.user_id, request_type=self.request_type, message_id=interaction.message.id)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="✏️ Редактировать", style=discord.ButtonStyle.secondary, custom_id="edit")
    async def edit_button(self, interaction: discord.Interaction, button: Button):
        if not interaction.message.embeds:
            await interaction.response.send_message("❌ У сообщения заявки отсутствует embed.", ephemeral=True)
            return
        embed = interaction.message.embeds[0]
        for field in embed.fields:
            if field.name == FieldNames.STATUS and ("✅" in field.value or "❌" in field.value):
                await interaction.response.send_message("❌ заявка уже обработана и не может быть отредактирована!", ephemeral=True)
                return

        try:
            import state as _state_for_store

            store = getattr(_state_for_store, "request_store", None)
        except Exception:
            store = None

        if store is not None:
            request_data = store.get_by_message_id(interaction.message.id) or {}
        else:
            from state import active_requests  # локальный импорт

            request_data = active_requests.get(interaction.message.id, {})
        modal = EditRequestModal(
            user_id=self.user_id,
            request_type=self.request_type,
            current_data=request_data,
            message_id=interaction.message.id
        )
        await interaction.response.send_modal(modal)

    async def handle_accept(self, interaction: discord.Interaction):
        member = interaction.guild.get_member(self.user_id)
        if not member:
            await interaction.response.send_message(ErrorMessages.NOT_FOUND.format(item="пользователь"), ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        try:
            if not getattr(interaction, "message", None):
                await interaction.followup.send("❌ Сообщение недоступно.", ephemeral=True)
                return
            async with action_lock(interaction.message.id, "принятие заявки"):
                try:
                    import state as _state_for_store
                    store = getattr(_state_for_store, "request_store", None)
                except Exception:
                    store = None
                if store is not None:
                    request_data = store.get_by_message_id(interaction.message.id)
                else:
                    from state import active_requests  # локальный импорт
                    request_data = active_requests.get(interaction.message.id)
                if not request_data:
                    await interaction.followup.send("⚠️ Заявка уже обработана.", ephemeral=True)
                    return

                dm_failed_message = None
                roles_to_give = self.request_type.get_roles_to_give()

                roles = []
                try:
                    role_cache = getattr(state, "role_cache", None)
                except Exception:
                    role_cache = None
                if role_cache is not None:
                    roles = [r for r in await role_cache.get_many_roles(interaction.guild.id, roles_to_give) if r]
                else:
                    roles = [interaction.guild.get_role(rid) for rid in roles_to_give if interaction.guild.get_role(rid)]
                await apply_role_changes(member, add=roles)

                nick_failed_message = None
                try:
                    prefix = self.request_type.get_nickname_prefix()
                    new_nick = f"{prefix} {self.validated_data['name']} {self.validated_data['surname']}"
                    await safe_discord_call(member.edit, nick=new_nick)
                except discord.Forbidden:
                    logger.warning("Нет прав на смену ника пользователю %s (роль выше бота или владелец сервера)", member.id)
                    nick_failed_message = f"⚠️ Не удалось сменить ник {member.mention} — роль пользователя выше роли бота или это владелец сервера."
                except Exception as e:
                    logger.error("ошибка при смене ника: %s", e, exc_info=True)
                    nick_failed_message = f"⚠️ Не удалось сменить ник {member.mention}."

                message_link = f"https://discord.com/channels/{interaction.guild.id}/{interaction.channel.id}/{interaction.message.id}"

                if self.request_type != RequestType.GOV:
                    await send_to_audit(
                        interaction,
                        member,
                        Config.ACTION_ACCEPTED,
                        Config.RANK_PRIVATE,
                        message_link
                    )


                dm_failed_message = None
                if self.request_type == RequestType.CADET:
                    from datetime import datetime
                    import random
                    from views.training_buttons import ExamView
                    from constants import ExamMessages

                    now = datetime.now()
                    report_id = f"УВД-{random.randint(1000, 9999)}"
                    herb_url = (getattr(Config, "EXAM_HERB_URL", None) or "").strip() or ExamMessages.HERB_URL
                    seal_url = (getattr(Config, "EXAM_SEAL_URL", None) or "").strip() or ExamMessages.SEAL_URL

                    order_text = Config.EXAM_ORDER_TEXT.format(
                        report_id=report_id,
                        day=now.day,
                        month=ExamMessages.MONTHS[now.month],
                        year=now.year,
                        name=self.validated_data["name"],
                    )

                    embed = discord.Embed(
                        title=Config.EXAM_WELCOME_TITLE,
                        description=order_text,
                        color=0x1E5F8C,
                        timestamp=discord.utils.utcnow(),
                    )
                    embed.set_author(
                        name=Config.EXAM_WELCOME_SUBTITLE,
                        icon_url=herb_url,
                    )
                    embed.set_thumbnail(url=herb_url)

                    full_name = f"{self.validated_data['name']} {self.validated_data['surname']}"
                    embed.add_field(name="👤 Кандидат", value=f"**{full_name}**", inline=True)
                    embed.add_field(name="📋 Статус", value="**Курсант**", inline=True)
                    embed.add_field(name="🆔 Номер рапорта", value=f"**{report_id}**", inline=True)
                    embed.add_field(name="👮 Принял", value=interaction.user.mention, inline=False)

                    embed.set_image(url=seal_url)
                    embed.set_footer(
                        text="Следующий шаг: перейдите в голосовой канал и нажмите кнопку ниже",
                        icon_url=herb_url,
                    )

                    view = ExamView(timeout_seconds=Config.EXAM_BUTTON_TIMEOUT)
                    try:
                        msg = await member.send(embed=embed, view=view)
                        await view.start_timer(msg, member.id)
                    except discord.Forbidden:
                        logger.warning("Не удалось отправить ЛС с экзаменом пользователю %s (DM закрыты)", member.id)
                        dm_failed_message = f"⚠️ Заявка принята, но не удалось отправить ЛС пользователю {member.mention}."
                    except discord.HTTPException as e:
                        logger.warning("HTTP ошибка отправки ЛС с экзаменом пользователю %s: %s", member.id, e)
                        dm_failed_message = f"⚠️ Заявка принята, но ЛС пользователю {member.mention} временно не доставлено."


                if not interaction.message.embeds:
                    await interaction.followup.send("❌ У сообщения заявки отсутствует embed.", ephemeral=True)
                    return
                embed = copy_embed(interaction.message.embeds[0])
                embed = update_embed_status(embed, StatusValues.ACCEPTED, GREEN)
                embed = add_officer_field(embed, interaction.user.mention)

                await interaction.message.edit(embed=embed, view=None)

                try:
                    import state as _state_for_store

                    store = getattr(_state_for_store, "request_store", None)
                except Exception:
                    store = None

                if store is not None:
                    await store.remove_active(interaction.message.id)
                else:
                    from state import active_requests  # локальный импорт

                    try:
                        await delete_request("requests", interaction.message.id)
                    except Exception as e:
                        logger.warning("Не удалось удалить request из БД message_id=%s: %s", interaction.message.id, e)
                    else:
                        if interaction.message.id in active_requests:
                            del active_requests[interaction.message.id]

                reply = f"✅ заявка принята! выдано ролей: {len(roles)}"
                warnings = [msg for msg in [nick_failed_message, dm_failed_message] if msg]
                if warnings:
                    reply = "\n".join([reply] + warnings)
                await interaction.followup.send(reply, ephemeral=True)

        except RuntimeError as e:
            if str(e) == "ACTION_ALREADY_IN_PROGRESS":
                await safe_followup_or_response(interaction, "⚠️ эта заявка уже обрабатывается другим нажатием.", ephemeral=True)
                return
            logger.error("ошибка блокировки заявки: %s", e, exc_info=True)
            await safe_followup_or_response(interaction, ErrorMessages.GENERIC, ephemeral=True)

        except Exception as e:
            logger.error("ошибка при принятии заявки: %s", e, exc_info=True)
            await safe_followup_or_response(interaction, ErrorMessages.GENERIC, ephemeral=True)