class StartMessages:
    TITLE = "Подача заявки"
    DESCRIPTION = (
        "**Выберите тип заявки:**\n\n"
        "🟢 **Курсант** — зачисление в академию\n"
        "🔵 **Перевод** — из другой структуры\n"
        "⚪ **Гос. сотрудник** — для гостей\n\n"
        "⏱ Новую заявку можно отправить через {cooldown} сек. Хранение: {expiry_days} дней."
    )


class WarehouseMessages:
    START_TITLE = "Склад УВД"
    START_DESCRIPTION = (
        "**Запрос снаряжения** — новый запрос или корзина.\n"
        "**Моя корзина** — текущий состав.\n\n"
        "Лимиты: оружие — 3 ед., броня — 20 шт., медицина — 45 шт. Ограничение: раз в {cooldown_hours} ч."
    )
    REQUEST_TITLE = "Заявка на снаряжение"
    REQUEST_FOOTER = "Создано: {time}"


class ErrorMessages:
    NO_PERMISSION = "❌ Недостаточно прав."
    NOT_FOUND = "❌ {item} не найден."
    GENERIC = "❌ Ошибка. Попробуйте позже."


class SuccessMessages:
    REQUEST_SENT = "✅ Заявка отправлена. Ожидайте рассмотрения."
    ACCEPTED = "✅ Заявка принята."
    EDITED = "✅ Заявка отредактирована."


class AcceptMessages:
    CADET = {"desc": "Заявка в **Академию УВД** одобрена.", "actions": "Ожидайте инструкций от ОРЛС."}
    TRANSFER = {"desc": "Заявка на **перевод** одобрена.", "actions": "Ожидайте инструкций по переаттестации."}
    GOV = {"desc": "Заявка для **гос. сотрудников** одобрена.", "actions": "Добро пожаловать в гости."}

    @classmethod
    def get(cls, key):
        messages = {"cadet": cls.CADET, "transfer": cls.TRANSFER, "gov": cls.GOV}
        return messages.get(key, cls.CADET)