import re
import logging
from typing import Dict, Any

import discord
from discord.ui import View, Select

from config import Config
from constants import FieldNames, StatusValues, EmbedTitles
from models import PromotionRequest
import state
from database import save_academy_draft, load_academy_draft, delete_academy_draft
from services.worker_queue import get_worker
from services.ranks import is_promotion_key_allowed_for_member, get_member_rank_display
from services.department_roles import get_dept_role_id
from services.promotion_common import has_active_promotion, get_reviewers_mention_content, drop_orphan_promotion_requests_for_user
from utils.promotion_helpers import (
    required_count_from_text,
    normalize_thanks,
    requirement_short_label,
    links_word,
    send_long,
)
from utils.interaction_helpers import safe_followup_or_response
from utils.validators import validate_user_link

logger = logging.getLogger(__name__)


PROMOTION_REQUIREMENTS_ACADEMY: Dict[str, Dict[str, Any]] = {
    "Рядовой -> Младший сержант": {
        "points": 0,
        "required": [
            'Прослушать лекцию на тему "Работа сотрудника УВД".',
            "Принять присягу сотрудника УВД по ЦАО.",
            'Сдать тестирование "Работа сотрудника УВД".',
            'Принять участие в тренировке "Строевая подготовка".',
            'Отстоять на посту "Ворота задние или передние" - 30 минут с докладом каждые 10 минут.',
        ],
    },
    "Младший сержант -> Сержант": {
        "points": 0,
        "required": [
            'Прослушать лекцию на тему "Теория и Законы".',
            'Патруль с сотрудником ППС, ОРЛС или ОСН "Гром" | разрешена замена на одиночный пеший патруль по прилегающему району к зданию УВД - 30 минут с докладом каждые 10 минут.',
            'Отстоять на посту "Балларды" - 30 минут с докладом каждые 10 минут.',
            'Сдать практический экзамен на тему "Задержание, арест и штрафы".',
            "Сдать итоговый экзамен.",
        ],
    },
}


def _sort_int_like(keys):
    return sorted(keys, key=lambda k: int(k) if str(k).isdigit() else -1)


def _build_collector_embed(draft: Dict[str, Any]) -> discord.Embed:
    promotion_key = draft.get("promotion_key", "")
    full_name = draft.get("full_name", "")
    req_links = draft.get("requirement_links") or {}
    info = PROMOTION_REQUIREMENTS_ACADEMY.get(promotion_key, {})
    required_list = info.get("required", [])
    points_required = int(info.get("points", 0) or 0)

    fulfilled = 0
    for idx, req in enumerate(required_list, start=1):
        need = required_count_from_text(req)
        if len(req_links.get(idx, [])) >= need:
            fulfilled += 1

    req_ok = fulfilled >= len(required_list) if required_list else True
    points_ok = True if points_required <= 0 else False
    can_submit = req_ok and points_ok

    if can_submit:
        color = discord.Color.green()
    elif fulfilled > 0:
        color = discord.Color.gold()
    else:
        color = discord.Color.from_rgb(128, 128, 128)

    summary_parts = []
    summary_parts.append(
        "Обязательные: **%s/%s** %s"
        % (fulfilled, len(required_list), "✓" if req_ok else "✗")
    )
    if points_required > 0:
        summary_parts.append(
            "Баллы: **%s** %s"
            % (points_required, "✓" if points_ok else "✗")
        )
    summary_parts.append("**Можно отправлять**" if can_submit else "Пока не готово")
    one_line = " · ".join(summary_parts)

    embed = discord.Embed(
        title="Добавьте ссылки по требованиям (Академия)",
        description="**%s** · %s\n\n%s\n\nВыберите требование и добавьте ссылки."
        % (full_name or "—", promotion_key or "—", one_line),
        color=color,
    )

    if points_required > 0:
        embed.add_field(
            name="Баллы (автоподсчёт)",
            value="Нужно для звания: **%s** б." % points_required,
            inline=False,
        )

    lines = []
    for idx, req in enumerate(required_list, start=1):
        need = required_count_from_text(req)
        count = len(req_links.get(idx, []))
        ok = "✓" if count >= need else "✗ (нужно %s)" % need
        short = requirement_short_label(req, 256)
        lines.append("**%s. %s** — %s %s %s" % (idx, short, count, links_word(count), ok))
    if lines:
        embed.add_field(name="Обязательные", value="\n".join(lines), inline=False)

    embed.set_footer(
        text="Когда всё добавлено — нажмите «Готово, отправить рапорт»."
    )
    return embed


class AcademyLinksModal(discord.ui.Modal, title="Ссылки (Академия)"):
    def __init__(self, label: str, requirement_index: int, user_id: int):
        super().__init__(timeout=None)
        self.requirement_index = requirement_index
        self.user_id = user_id

        placeholder = "По одной ссылке в строку."
        if len(placeholder) > 100:
            placeholder = placeholder[:97] + "..."

        self.links_field = discord.ui.TextInput(
            label=label[:45],
            style=discord.TextStyle.paragraph,
            required=True,
            max_length=2000,
            placeholder=placeholder[:100],
        )
        self.add_item(self.links_field)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            if interaction.user and interaction.user.id != self.user_id:
                await interaction.response.send_message(
                    "❌ Это не ваш черновик.", ephemeral=True
                )
                return

            drafts = getattr(state, "academy_draft_reports", None)
            if drafts is None:
                state.academy_draft_reports = {}
                drafts = state.academy_draft_reports

            draft = drafts.get(self.user_id)
            if not draft:
                await interaction.response.send_message(
                    "Сессия истекла. Начните рапорт заново.",
                    ephemeral=True,
                )
                return

            raw = (self.links_field.value or "").strip()
            urls = [
                s.strip()
                for s in raw.splitlines()
                if s.strip()
                and validate_user_link(s.strip())
            ]
            draft.setdefault("requirement_links", {}).setdefault(
                self.requirement_index, []
            ).extend(urls)

            snapshot = {k: v for k, v in draft.items() if k != "_ephemeral_msg"}
            try:
                get_worker().submit_fire(save_academy_draft, self.user_id, snapshot)
            except Exception:
                logger.debug("AcademyLinksModal: submit_fire save_academy_draft не удалось", exc_info=True)
                pass

            embed = _build_collector_embed(draft)
            view = AcademyCollectorView(draft.get("promotion_key", ""), self.user_id)
            await interaction.response.defer(ephemeral=True)
            content_full = (
                "Добавлено %s: **%s**. Ниже — актуальное состояние."
                % (links_word(len(urls)), len(urls))
            )
            if interaction.message:
                try:
                    await interaction.message.edit(
                        content=content_full, embed=embed, view=view
                    )
                except Exception:
                    logger.debug("AcademyLinksModal: не удалось отредактировать сообщение, fallback на followup", exc_info=True)
                    await interaction.followup.send(
                        content=content_full,
                        embed=embed,
                        view=view,
                        ephemeral=True,
                    )
            else:
                await interaction.followup.send(
                    "Добавлено %s: **%s**. Состояние обновится при следующем действии."
                    % (links_word(len(urls)), len(urls)),
                    ephemeral=True,
                )
        except Exception as e:
            logger.error("Ошибка AcademyLinksModal: %s", e, exc_info=True)
            await safe_followup_or_response(interaction, "Ошибка.", ephemeral=True)


async def _do_submit_report(draft: Dict[str, Any], interaction: discord.Interaction):
    ch = interaction.channel
    if not ch or not isinstance(ch, discord.TextChannel):
        await interaction.followup.send("Канал не найден.", ephemeral=True)
        return
    try:
        user_id_int = int(draft.get("discord_id", 0))
    except (TypeError, ValueError):
        await interaction.followup.send("Некорректные данные.", ephemeral=True)
        return

    full_name = draft.get("full_name", "—")
    promotion_key = draft.get("promotion_key", "")
    passport = draft.get("passport", "—")
    requirement_links = draft.get("requirement_links") or {}
    info = PROMOTION_REQUIREMENTS_ACADEMY.get(promotion_key, {})
    required_list = info.get("required", [])

    embed = discord.Embed(
        title=EmbedTitles.PROMOTION,
        color=discord.Color.gold(),
        description=(
            "Рапорт на повышение в Академии\n\n"
            "👤 %s | %s\nDiscord: <@%s> (%s)"
            % (full_name, promotion_key, user_id_int, user_id_int)
        ),
        timestamp=interaction.created_at,
    )
    embed.add_field(name=FieldNames.FULL_NAME, value=full_name, inline=False)
    embed.add_field(name=FieldNames.NEW_RANK, value=promotion_key, inline=True)
    embed.add_field(name="Паспорт", value=passport, inline=True)
    embed.add_field(
        name=FieldNames.STATUS,
        value=StatusValues.PENDING,
        inline=True,
    )
    embed.set_footer(
        text=interaction.user.display_name if interaction.user else "",
        icon_url=(getattr(getattr(interaction.user, "display_avatar", None), "url", None) if interaction.user else None),
    )

    from views.promotion_view import PromotionView

    view = PromotionView(
        user_id=user_id_int,
        new_rank=promotion_key,
        full_name=full_name,
        message_id=0,
    )
    content = get_reviewers_mention_content(ch.id)
    message = await ch.send(content=content or None, embed=embed, view=view)

    promo_request = PromotionRequest(
        discord_id=user_id_int,
        full_name=full_name,
        new_rank=promotion_key,
        message_link=message.jump_url,
    )

    promo_store = getattr(state, "promotion_store", None)
    if promo_store is not None:
        await get_worker().submit(promo_store.upsert_active, message.id, promo_request.to_dict())
    else:
        from state import active_promotion_requests  # локальный импорт
        from database import save_request as _save_promo_legacy

        active_promotion_requests[message.id] = promo_request.to_dict()
        await get_worker().submit(
            _save_promo_legacy, "promotion_requests", message.id, promo_request.to_dict()
        )
    view.message_id = message.id
    try:
        await message.edit(view=view)
    except Exception as e:
        logger.warning("Не обновить view рапорта Академии: %s", e)

    if required_list or requirement_links:
        try:
            thread = await message.create_thread(
                name="АКАДЕМИЯ • %s • %s" % (full_name[:80], promotion_key[:30])
            )
        except discord.HTTPException:
            thread = getattr(message, "thread", None)
        if thread:
            copy_text = (
                "```\n"
                "%s | %s\n"
                "%s\n"
                "Согласно: %s\n"
                "```"
            ) % (full_name, passport, promotion_key, message.jump_url)
            await thread.send(copy_text)
            
            intro = discord.Embed(
                title="📋 Рапорт на повышение Академии",
                description=(
                    "👤 **%s**\n"
                    "🪪 Паспорт: **%s**\n"
                    "📈 Повышение: **%s**"
                ) % (full_name, passport, promotion_key),
                color=discord.Color.blue(),
            )
            await thread.send(embed=intro)
            
            header = "**📋 Обязательные требования Академии**\n"
            blocks = []
            for idx, req in enumerate(required_list, start=1):
                need = required_count_from_text(req)
                urls = requirement_links.get(idx, [])
                count = len(urls)
                ok = count >= need
                icon = "✅" if ok else "❌"
                status = "" if ok else " (нужно ещё %s)" % need
                lines = [
                    "%s **%s.** %s — %s %s%s"
                    % (icon, idx, req, count, links_word(count), status)
                ]
                lines += [
                    "   └ %s. %s" % (i, u)
                    for i, u in enumerate(urls, start=1)
                ] if urls else ["   └ ссылок нет"]
                blocks.append("\n".join(lines))
            body = "\n\n".join(blocks)
            await send_long(thread, body, header=header)

    await interaction.followup.send(
        "Рапорт Академии отправлен.", ephemeral=True
    )
    logger.info(
        "Рапорт Академии отправлен: user_id=%s, msg_id=%s",
        user_id_int,
        message.id,
    )


class AcademyConfirmSubmitView(View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.user_id = user_id
        yes_btn = discord.ui.Button(
            label="Да, отправить",
            style=discord.ButtonStyle.danger,
            custom_id="academy_confirm_yes",
        )
        yes_btn.callback = self._cb_yes
        no_btn = discord.ui.Button(
            label="Нет, вернуться",
            style=discord.ButtonStyle.secondary,
            custom_id="academy_confirm_no",
        )
        no_btn.callback = self._cb_no
        self.add_item(yes_btn)
        self.add_item(no_btn)

    async def _cb_yes(self, interaction: discord.Interaction):
        if interaction.user and interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "❌ Это не ваш черновик.", ephemeral=True
            )
            return
        drafts = getattr(state, "academy_draft_reports", None) or {}
        draft = drafts.pop(self.user_id, None)
        if not draft:
            await interaction.response.send_message(
                "Сессия истекла. Начните рапорт заново.", ephemeral=True
            )
            return
        await interaction.response.defer(ephemeral=True)
        await _do_submit_report(draft, interaction)

    async def _cb_no(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            "Добавьте ещё ссылок и нажмите «Готово» снова.",
            ephemeral=True,
        )


class AcademyCollectorView(View):
    def __init__(self, promotion_key: str, owner_id: int):
        super().__init__(timeout=604800)
        self.promotion_key = promotion_key
        self.owner_id = owner_id
        info = PROMOTION_REQUIREMENTS_ACADEMY.get(promotion_key, {})
        req_list = info.get("required", [])

        req_opts = [
            discord.SelectOption(
                label=("%s. %s" % (i, requirement_short_label(r, 80))),
                value=str(i),
                description="Добавить ссылки",
            )
            for i, r in enumerate(req_list, start=1)
        ]
        if req_opts:
            self.req_select = discord.ui.Select(
                placeholder="Добавить ссылки по требованию",
                min_values=1,
                max_values=1,
                options=req_opts,
                custom_id="academy_req_sel",
            )
            self.req_select.callback = self._cb_req
            self.add_item(self.req_select)

        done_btn = discord.ui.Button(
            label="Готово, отправить рапорт",
            style=discord.ButtonStyle.success,
            custom_id="academy_done",
        )
        done_btn.callback = self._cb_done
        self.add_item(done_btn)

    async def _cb_req(self, interaction: discord.Interaction):
        if not interaction.user:
            await safe_followup_or_response(
                interaction, "❌ Ошибка: не удалось определить пользователя.", ephemeral=True
            )
            return
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "❌ Это не ваш черновик.", ephemeral=True
            )
            return

        drafts = getattr(state, "academy_draft_reports", None)
        if drafts is None:
            state.academy_draft_reports = {}
            drafts = state.academy_draft_reports

        draft = drafts.get(self.owner_id)
        if not draft:
            await interaction.response.send_message(
                "Черновик не найден. Начните рапорт заново.",
                ephemeral=True,
            )
            return

        vals = interaction.data.get("values", []) if interaction.data else []
        idx = int(vals[0]) if vals else 1
        info = PROMOTION_REQUIREMENTS_ACADEMY.get(
            draft.get("promotion_key", ""), {}
        )
        reqs = info.get("required", [])
        label = reqs[idx - 1] if idx <= len(reqs) else "Требование %s" % idx
        await interaction.response.send_modal(
            AcademyLinksModal(label, requirement_index=idx, user_id=interaction.user.id)
        )

    async def _cb_done(self, interaction: discord.Interaction):
        uid = interaction.user.id if interaction.user else 0
        if not uid:
            await safe_followup_or_response(
                interaction, "❌ Ошибка: не удалось определить пользователя.", ephemeral=True
            )
            return
        if uid != self.owner_id:
            await interaction.response.send_message(
                "❌ Это не ваш черновик.", ephemeral=True
            )
            return

        drafts = getattr(state, "academy_draft_reports", None) or {}
        draft = drafts.get(uid)
        if not draft:
            await interaction.response.send_message(
                "Черновик не найден. Начните заново через «Подать рапорт».",
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)
        info = PROMOTION_REQUIREMENTS_ACADEMY.get(
            draft.get("promotion_key", ""), {}
        )
        required_list = info.get("required", [])
        req_links = draft.get("requirement_links") or {}

        fulfilled = 0
        for idx, req in enumerate(required_list, start=1):
            if len(req_links.get(idx, [])) >= required_count_from_text(req):
                fulfilled += 1

        req_ok = fulfilled >= len(required_list) if required_list else True
        if req_ok:
            drafts.pop(uid, None)
            get_worker().submit_fire(delete_academy_draft, uid)
            await _do_submit_report(draft, interaction)
        else:
            missing = "обязательные %s/%s" % (fulfilled, len(required_list))
            await interaction.followup.send(
                "Не выполнено: %s. Всё равно отправить?" % missing,
                view=AcademyConfirmSubmitView(uid),
                ephemeral=True,
            )


class AcademyPromotionModal(discord.ui.Modal, title="Рапорт на повышение Академии"):
    def __init__(self, promotion_key: str, user_id: int | None = None):
        super().__init__(timeout=None)
        self.promotion_key = promotion_key
        last = getattr(state, "academy_last_user_data", {}).get(user_id or 0, {})  # type: ignore[arg-type]
        discord_default = str(user_id) if user_id else ""
        self.full_name = discord.ui.TextInput(
            label="Имя Фамилия",
            max_length=Config.MAX_NAME_LENGTH,
            required=True,
            default=last.get("full_name", "")[: Config.MAX_NAME_LENGTH],
        )
        self.discord_id = discord.ui.TextInput(
            label="Discord ID",
            max_length=32,
            required=True,
            placeholder="Числовой ID",
            default=last.get("discord_id") or discord_default,
        )
        self.passport = discord.ui.TextInput(
            label="Номер паспорта",
            max_length=Config.STATIC_ID_LENGTH,
            required=False,
            default=last.get("passport", "")[: Config.STATIC_ID_LENGTH],
        )
        self.add_item(self.full_name)
        self.add_item(self.discord_id)
        self.add_item(self.passport)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            if not interaction.guild or not isinstance(
                interaction.channel, discord.TextChannel
            ):
                await interaction.response.send_message(
                    "Рапорт можно подать только в текстовом канале.",
                    ephemeral=True,
                )
                return

            role_academy = getattr(Config, "ROLE_ACADEMY", 0)
            role_dept_academy = getattr(Config, "ROLE_DEPT_ACADEMY", 0)
            if (role_academy or role_dept_academy) and isinstance(
                interaction.user, discord.Member
            ):
                guild = interaction.guild
                has_academy = False
                if role_academy and guild:
                    r = guild.get_role(role_academy)
                    if r and r in interaction.user.roles:
                        has_academy = True
                if not has_academy and role_dept_academy and guild:
                    r = guild.get_role(role_dept_academy)
                    if r and r in interaction.user.roles:
                        has_academy = True
                if not has_academy:
                    await interaction.response.send_message(
                        "❌ Подать рапорт Академии могут только участники академии или сотрудники отдела Академии.",
                        ephemeral=True,
                    )
                    return

            if isinstance(Config.PROMOTION_CHANNELS, dict) and (
                interaction.channel.id not in Config.PROMOTION_CHANNELS
            ):
                await interaction.response.send_message(
                    "Этот канал не настроен как канал рапортов Академии.",
                    ephemeral=True,
                )
                return

            try:
                user_id = int(str(self.discord_id.value).strip())
            except ValueError:
                await interaction.response.send_message(
                    "Некорректный Discord ID.", ephemeral=True
                )
                return

            drafts = getattr(state, "academy_draft_reports", None)
            if drafts is None:
                state.academy_draft_reports = {}
                drafts = state.academy_draft_reports

            draft = {
                "channel_id": interaction.channel.id,
                "promotion_key": self.promotion_key,
                "full_name": self.full_name.value.strip(),
                "discord_id": str(user_id),
                "passport": self.passport.value.strip() or "—",
                "requirement_links": {},
                "thanks_links": [],
            }

            collector_embed = _build_collector_embed(draft)
            collector_view = AcademyCollectorView(
                self.promotion_key, interaction.user.id
            )
            await interaction.response.send_message(
                content=(
                    "Данные приняты. Добавляйте ссылки по каждому требованию "
                    "и нажмите «Готово, отправить рапорт»."
                ),
                embed=collector_embed,
                view=collector_view,
                ephemeral=True,
            )

            draft["message_id"] = None
            draft["channel_id"] = interaction.channel.id
            drafts[interaction.user.id] = draft

            snapshot = {k: v for k, v in draft.items() if k != "_ephemeral_msg"}
            get_worker().submit_fire(save_academy_draft, interaction.user.id, snapshot)

            last_data = getattr(state, "academy_last_user_data", None)
            if last_data is None:
                state.academy_last_user_data = {}
                last_data = state.academy_last_user_data
            last_data[interaction.user.id] = {
                "full_name": draft["full_name"],
                "discord_id": draft["discord_id"],
                "passport": draft["passport"],
            }
        except Exception as e:
            logger.error("Ошибка AcademyPromotionModal: %s", e, exc_info=True)
            await safe_followup_or_response(interaction, "Ошибка при отправке.", ephemeral=True)


class AcademyPromotionSelect(Select):
    def __init__(self):
        options = [
            discord.SelectOption(
                label=key,
                value=key,
                description="Требований: %s" % len(info.get("required", [])),
            )
            for key, info in PROMOTION_REQUIREMENTS_ACADEMY.items()
        ]
        super().__init__(
            placeholder="Выберите повышение Академии",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="academy_promotion_select",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        try:
            if isinstance(interaction.user, discord.Member) and interaction.guild:
                role_academy = getattr(Config, "ROLE_ACADEMY", 0)
                role_dept_academy = getattr(Config, "ROLE_DEPT_ACADEMY", 0)
                if role_academy or role_dept_academy:
                    guild = interaction.guild
                    has_academy = False
                    if role_academy and guild:
                        role = guild.get_role(role_academy)
                        if role and role in interaction.user.roles:
                            has_academy = True
                    if not has_academy and role_dept_academy and guild:
                        role = guild.get_role(role_dept_academy)
                        if role and role in interaction.user.roles:
                            has_academy = True
                    if not has_academy:
                        await interaction.response.send_message(
                            "❌ Подать рапорт Академии могут только участники академии или сотрудники отдела Академии.",
                            ephemeral=True,
                        )
                        return

            promotion_key = self.values[0]
            if not is_promotion_key_allowed_for_member(
                interaction.user, promotion_key
            ):
                current = get_member_rank_display(interaction.user) or "не определено"
                await interaction.response.send_message(
                    "Рапорт можно подать только на следующее звание. "
                    "Ваше текущее звание: **%s**. Выберите повышение, соответствующее вашему званию."
                    % current,
                    ephemeral=True,
                )
                return

            user_id = interaction.user.id if interaction.user else None
            if user_id:
                await drop_orphan_promotion_requests_for_user(user_id, interaction.client)
            if user_id and await has_active_promotion(user_id):
                await interaction.response.send_message(
                    "❌ У вас уже есть активный рапорт на повышение. "
                    "Дождитесь решения по текущему рапорту.",
                    ephemeral=True,
                )
                return

            await interaction.response.send_modal(
                AcademyPromotionModal(promotion_key=promotion_key, user_id=user_id)
            )
        except Exception as e:
            logger.error("Ошибка открытия модала Академии: %s", e, exc_info=True)
            await safe_followup_or_response(interaction, "Ошибка.", ephemeral=True)


class AcademyPromotionApplyView(View):
    timeout = None

    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(AcademyPromotionSelect())
        resume_btn = discord.ui.Button(
            label="Продолжить мой рапорт",
            style=discord.ButtonStyle.secondary,
            custom_id="academy_resume_draft",
        )
        resume_btn.callback = self._cb_resume_draft
        self.add_item(resume_btn)

    async def _cb_resume_draft(self, interaction: discord.Interaction) -> None:
        if not interaction.user:
            await safe_followup_or_response(
                interaction, "❌ Ошибка: не удалось определить пользователя.", ephemeral=True
            )
            return
        if isinstance(interaction.user, discord.Member) and interaction.guild:
            role_academy = getattr(Config, "ROLE_ACADEMY", 0)
            role_dept_academy = getattr(Config, "ROLE_DEPT_ACADEMY", 0)
            if role_academy or role_dept_academy:
                guild = interaction.guild
                has_academy = False
                if role_academy and guild:
                    r = guild.get_role(role_academy)
                    if r and r in interaction.user.roles:
                        has_academy = True
                if not has_academy and role_dept_academy and guild:
                    r = guild.get_role(role_dept_academy)
                    if r and r in interaction.user.roles:
                        has_academy = True
                if not has_academy:
                    await interaction.response.send_message(
                        "❌ Продолжить рапорт Академии могут только участники академии или сотрудники отдела Академии.",
                        ephemeral=True,
                    )
                    return
        uid = interaction.user.id
        if getattr(state, "academy_draft_reports", None) is None:
            state.academy_draft_reports = {}
        drafts = state.academy_draft_reports
        draft = drafts.get(uid)
        if not draft:
            try:
                draft = await get_worker().submit(load_academy_draft, uid)
            except Exception:
                logger.debug("academy_promotion open_modal: load_academy_draft не удалось для uid=%s", uid, exc_info=True)
                draft = None
        if draft:
            drafts[uid] = draft
        if not draft:
            await drop_orphan_promotion_requests_for_user(uid, interaction.client)
            if await has_active_promotion(uid):
                await interaction.response.send_message(
                    "✅ Ваш рапорт уже отправлен и ожидает проверки. Дождитесь решения по нему.",
                    ephemeral=True,
                )
            else:
                await interaction.response.send_message(
                    "У вас нет черновика рапорта Академии. Выберите повышение выше, чтобы начать новый рапорт.",
                    ephemeral=True,
                )
            return
        promotion_key = draft.get("promotion_key", "")
        collector_embed = _build_collector_embed(draft)
        collector_view = AcademyCollectorView(promotion_key, uid)
        await interaction.response.send_message(
            content="Продолжайте добавлять ссылки и нажмите «Готово, отправить рапорт», когда всё будет готово.",
            embed=collector_embed,
            view=collector_view,
            ephemeral=True,
        )

