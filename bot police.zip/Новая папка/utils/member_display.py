

import re
from typing import Tuple

import discord

_SEP = " | "
_SEP_PATTERN = re.compile(r"\s*\|\s*", re.IGNORECASE)

# Варианты вертикальной черты (в т.ч. полная ширина), чтобы парсить display_name одинаково
_PIPE_CHARS = ("\uFF5C", "\u2502", "｜", "│")


def _normalize_pipe(s: str) -> str:
    """Приводит все варианты вертикальной черты к ASCII |."""
    if not s:
        return s
    for c in _PIPE_CHARS:
        s = s.replace(c, "|")
    return s


def name_after_display_pipe(display: str) -> str:
    """Возвращает часть строки после первого «|» (учёт ｜, │ и т.д.). Если разделителя нет — саму строку."""
    if not (display or "").strip():
        return (display or "").strip()
    s = _normalize_pipe(display.strip())
    if "|" in s:
        return s.split("|", 1)[-1].strip()
    return s


def get_member_name_surname(member: discord.Member | None) -> Tuple[str, str]:
    if not member:
        return "", ""
    raw = (member.display_name or member.name or "").strip()
    raw = _normalize_pipe(raw)
    if not raw:
        return "", ""
    parts = _SEP_PATTERN.split(raw, 1)
    if len(parts) >= 2:
        name_surname = (parts[1] or "").strip()
    else:
        name_surname = (parts[0] or "").strip()
    if not name_surname:
        return "", ""
    tokens = name_surname.split(None, 1)
    if len(tokens) >= 2:
        return tokens[0].strip(), tokens[1].strip()
    return tokens[0].strip(), ""


def get_member_full_name(member: discord.Member | None) -> str:
    name, surname = get_member_name_surname(member)
    return f"{name} {surname}".strip()
