# -*- coding: utf-8 -*-
import re


def links_word(count: int) -> str:
    """Склонение: 1 ссылка, 2+ ссылок."""
    return "ссылка" if count == 1 else "ссылок"


def requirement_short_label(text: str, max_len: int = 80) -> str:
    """Часть строки требования до стрелки (→, ->, ➡, ⇒). Устойчиво к разным символам стрелки."""
    if not (text or "").strip():
        return ""
    s = text.strip()
    for arrow in ("->", "➡", "⇒"):
        s = s.replace(arrow, "→")
    return s.split("→", 1)[0].strip()[:max_len]


def required_count_from_text(requirement_text: str) -> int:
    if not (requirement_text or "").strip():
        return 1
    text = requirement_text.strip()
    m_шт = re.search(r"→\s*(\d+)\s*шт\.?", text, re.IGNORECASE)
    if m_шт:
        return int(m_шт.group(1))
    if re.search(r"\d+\s*минут", text, re.IGNORECASE) or re.search(r"\d+\s*мин\b", text, re.IGNORECASE):
        return 1
    m = re.search(r"→\s*(\d+)\s*(?:шт\.?|минут)", text, re.IGNORECASE)
    return int(m.group(1)) if m else 1


def parse_thanks_lines(text: str) -> list[list]:
    from utils.validators import validate_user_link
    result = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        try:
            n = int(parts[0])
        except ValueError:
            continue
        if n <= 0:
            continue
        url = parts[1].strip()
        if not validate_user_link(url):
            continue
        result.append([n, url])
    return result


async def send_long(thread, body: str, header: str = ""):
    if not thread:
        return
    max_len = 1990  # Discord content limit 2000
    if header:
        body = header + "\n" + body
    lines = body.split("\n")
    chunk = []
    current_len = 0
    for line in lines:
        line_len = len(line) + 1
        if line_len > max_len:
            if chunk:
                await thread.send("\n".join(chunk))
                chunk = []
                current_len = 0
            rest = line
            while len(rest) > max_len:
                await thread.send(rest[:max_len])
                rest = rest[max_len:]
            if rest:
                chunk.append(rest)
                current_len = len(rest) + 1
            continue
        if current_len + line_len > max_len and chunk:
            await thread.send("\n".join(chunk))
            chunk = []
            current_len = 0
        chunk.append(line)
        current_len += line_len
    if chunk:
        text = "\n".join(chunk)
        if len(text) > max_len:
            await thread.send(text[:max_len])
            await send_long(thread, text[max_len:].lstrip("\n"))
        else:
            await thread.send(text)


def normalize_thanks(thanks_links) -> list[list]:
    if not thanks_links:
        return []
    return [[int(p), str(u)] for p, u in thanks_links]


def normalize_bonus_links(bonus_links: dict) -> dict:
    """
    Нормализует bonus_links к формату {type: [[url, count], ...]}.
    
    Поддерживает оба формата:
    - Старый: {type: [url1, url2, ...]} — каждый URL = 1 шт.
    - Новый: {type: [[url, count], [url, count], ...]}
    """
    if not bonus_links:
        return {}
    result = {}
    for t, links in bonus_links.items():
        if not links:
            continue
        normalized = []
        for item in links:
            if isinstance(item, list) and len(item) == 2:
                url, count = item
                normalized.append([str(url), int(count)])
            elif isinstance(item, str):
                normalized.append([item, 1])
            else:
                normalized.append([str(item), 1])
        result[t] = normalized
    return result


def calc_bonus_points(bonus_links: dict, points_map: dict) -> int:
    """
    Подсчитывает общее количество баллов из bonus_links.
    Поддерживает оба формата (старый и новый).
    """
    normalized = normalize_bonus_links(bonus_links)
    total = 0
    for t, links in normalized.items():
        try:
            key = int(t) if str(t).isdigit() else t
        except Exception:
            key = t
        pts_per_item = int(points_map.get(key, 0))
        for url, count in links:
            total += pts_per_item * count
    return total


def calc_bonus_items_count(bonus_links: dict, bonus_type) -> int:
    """
    Подсчитывает общее количество фиксаций для данного типа бонуса.
    """
    normalized = normalize_bonus_links(bonus_links)
    links = normalized.get(bonus_type, [])
    if not links:
        key_str = str(bonus_type)
        links = normalized.get(key_str, [])
    return sum(count for url, count in links)
