# -*- coding: utf-8 -*-
"""
Утилиты для безопасного ответа на Discord interaction.
Используются для единообразной обработки ответа после defer или при ошибках.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

import discord

logger = logging.getLogger(__name__)


async def safe_defer(interaction: discord.Interaction, *, ephemeral: bool = True) -> bool:
    """
    Вызвать response.defer, если ещё не ответили. Не бросает при закрытом interaction.
    Возвращает True если defer выполнен или уже был выполнен, False при ошибке.
    """
    if interaction.response.is_done():
        return True
    try:
        await interaction.response.defer(ephemeral=ephemeral)
        return True
    except asyncio.CancelledError:
        raise
    except discord.NotFound:
        logger.debug("Interaction уже недоступен при defer")
        return False
    except discord.HTTPException as e:
        logger.warning("Не удалось defer interaction: %s", e)
        return False


async def safe_followup_or_response(
    interaction: discord.Interaction,
    content: str | None = None,
    *,
    embed: discord.Embed | None = None,
    view: discord.ui.View | None = None,
    ephemeral: bool = True,
    **kwargs: Any,
) -> None:
    """
    Отправить ответ пользователю: followup если response уже использован, иначе response.send_message.
    Не бросает исключений при уже закрытом interaction (логирует и выходит).
    """
    send_kwargs: dict[str, Any] = {
        "content": content,
        "embed": embed,
        "ephemeral": ephemeral,
        **kwargs,
    }
    if view is not None:
        send_kwargs["view"] = view
    try:
        if interaction.response.is_done():
            await interaction.followup.send(**send_kwargs)
        else:
            await interaction.response.send_message(**send_kwargs)
    except asyncio.CancelledError:
        raise
    except discord.NotFound:
        logger.debug("Interaction уже недоступен (сообщение/канал удалены)")
    except discord.HTTPException as e:
        logger.warning("Не удалось отправить ответ на interaction: %s", e)
