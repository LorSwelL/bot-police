#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import logging
from urllib.parse import urlparse

from config import Config

logger = logging.getLogger(__name__)

# Максимальная длина одной пользовательской ссылки в рапортах (academy/osb)
USER_LINK_MAX_LENGTH = 2000


def validate_user_link(url: str) -> bool:
    """
    Проверка пользовательской ссылки для рапортов: только https, валидный хост, ограничение длины.
    Возвращает True, если ссылка допустима.
    """
    if not url or not isinstance(url, str):
        return False
    s = url.strip()
    if len(s) > USER_LINK_MAX_LENGTH:
        return False
    try:
        parsed = urlparse(s)
        return parsed.scheme == "https" and bool(parsed.netloc)
    except Exception:
        return False


class Validators:
    @staticmethod
    def validate_name(name: str):
        try:
            name = name.strip()
            if not name:
                return False, "имя не может быть пустым"
            if len(name) < Config.MIN_NAME_LENGTH:
                return False, f"имя должно содержать минимум {Config.MIN_NAME_LENGTH} символа"
            if len(name) > Config.MAX_NAME_LENGTH:
                return False, f"имя не может быть длиннее {Config.MAX_NAME_LENGTH} символов"
            if not re.match(Config.NAME_PATTERN, name):
                return False, "имя может содержать только буквы, дефис и пробел"
            if re.search(r'\d', name):
                return False, "имя не может содержать цифры"
            formatted_name = " ".join(word.capitalize() for word in name.split())
            return True, formatted_name
        except Exception as e:
            logger.error("ошибка валидации имени: %s", e, exc_info=True)
            return False, "ошибка при проверке имени"

    @staticmethod
    def format_static_id(static_id: str):
        try:
            numbers = re.sub(r'\D', '', static_id)
            if not numbers:
                return False, "static id не может быть пустым"
            if not numbers.isdigit():
                return False, "static id может содержать только цифры"
            if len(numbers) != Config.STATIC_ID_LENGTH:
                return False, f"static id должен содержать ровно {Config.STATIC_ID_LENGTH} цифр"
            formatted_id = Config.STATIC_ID_FORMAT.format(numbers[:3], numbers[3:])
            return True, formatted_id
        except Exception as e:
            logger.error("ошибка форматирования static id: %s", e, exc_info=True)
            return False, "ошибка при обработке static id"

    @staticmethod
    def validate_reason(reason: str, require_link: bool = False):
        try:
            reason = reason.strip()
            if not reason:
                return False, "поле не может быть пустым"
            if len(reason) > Config.MAX_REASON_LENGTH:
                return False, f"текст слишком длинный (максимум {Config.MAX_REASON_LENGTH} символов)"
            if require_link and not re.match(Config.URL_PATTERN, reason):
                return False, "пожалуйста, укажите корректную ссылку"
            return True, reason
        except Exception as e:
            logger.error("ошибка валидации причины: %s", e, exc_info=True)
            return False, "ошибка при проверке текста"

    @staticmethod
    def validate_rank(rank: str):
        try:
            rank = rank.strip()
            if not rank:
                return False, "звание не может быть пустым"
            if len(rank) > Config.MAX_RANK_LENGTH:
                return False, f"звание слишком длинное (максимум {Config.MAX_RANK_LENGTH} символов)"
            if not re.match(Config.RANK_PATTERN, rank):
                return False, "звание может содержать только буквы, пробел, дефис и точку"
            return True, rank
        except Exception as e:
            logger.error("ошибка валидации звания: %s", e, exc_info=True)
            return False, "ошибка при проверке звания"